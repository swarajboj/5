package com.alish.navigationflowsample.presentation.ui.fragments.sign.up

import androidx.fragment.app.Fragment
import com.alish.navigationflowsample.R

class SignUpFragment : Fragment(R.layout.fragment_sign_up)