package com.alish.navigationflowsample.data.local

object UserData {

    var isAuthorized = false
}