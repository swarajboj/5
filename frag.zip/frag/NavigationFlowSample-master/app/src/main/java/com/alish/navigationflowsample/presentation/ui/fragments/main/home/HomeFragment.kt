package com.alish.navigationflowsample.presentation.ui.fragments.main.home

import androidx.fragment.app.Fragment
import com.alish.navigationflowsample.R

class HomeFragment : Fragment(R.layout.fragment_home)