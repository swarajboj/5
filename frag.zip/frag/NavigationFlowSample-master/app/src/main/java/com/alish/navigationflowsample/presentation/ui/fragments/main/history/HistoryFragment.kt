package com.alish.navigationflowsample.presentation.ui.fragments.main.history

import androidx.fragment.app.Fragment
import com.alish.navigationflowsample.R

class HistoryFragment : Fragment(R.layout.fragment_history)