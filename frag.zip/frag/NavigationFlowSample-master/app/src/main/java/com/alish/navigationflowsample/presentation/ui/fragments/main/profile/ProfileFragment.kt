package com.alish.navigationflowsample.presentation.ui.fragments.main.profile

import androidx.fragment.app.Fragment
import com.alish.navigationflowsample.R

class ProfileFragment : Fragment(R.layout.fragment_profile)