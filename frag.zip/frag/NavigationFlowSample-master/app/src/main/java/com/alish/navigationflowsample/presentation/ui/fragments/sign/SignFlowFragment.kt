package com.alish.navigationflowsample.presentation.ui.fragments.sign

import com.alish.navigationflowsample.R
import com.alish.navigationflowsample.presentation.base.BaseFlowFragment

class SignFlowFragment : BaseFlowFragment(
    R.layout.flow_fragment_sign, R.id.nav_host_fragment_sign
)