# Navigation Flow Sample

• [Single Activity с Navigation Component. Или как я мучался с графами. Boilerplate ч. 1](https://habr.com/ru/post/654599/)
